res111 = [[0 for i in range(6)] for j in range(8)]

print(res111)